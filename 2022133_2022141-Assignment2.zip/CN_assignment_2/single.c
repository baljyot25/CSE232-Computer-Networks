#include <unistd.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <ctype.h>

// Define the process information structure
typedef struct {
    long pid;
    long user;
    long kernel;
    char name[256];
    long total;
} ProcessInfo;

// Helper function to check if a string is a number
int is_num(const char *str) {
    while (*str) {
        if (!isdigit(*str)) {
            return 0;
        }
        str++;
    }
    return 1;
}

// Function to retrieve the two processes with the maximum total times and return as a formatted string
char* get_top_two_processes() {
    DIR *proc_dir;
    struct dirent *entry;

    // Open the /proc directory
    proc_dir = opendir("/proc");
    if (proc_dir == NULL) {
        perror("opendir");
        return NULL;
    }

    // Initialize the max1 and max2 process info structs
    ProcessInfo max1 = {0, 0, 0, "", -1};  // Process with max total time
    ProcessInfo max2 = {0, 0, 0, "", -1};  // Process with second max total time

    // Buffer to hold the final result
    char *result = (char *)malloc(1024);  // Allocate memory for the result string
    if (result == NULL) {
        perror("malloc");
        closedir(proc_dir);
        return NULL;
    }
    result[0] = '\0';  // Initialize the result buffer with an empty string

    // Iterate over the entries in /proc
    while ((entry = readdir(proc_dir)) != NULL) {
        const char *direc_name = entry->d_name;
        // Check if the directory name is a PID (i.e., all digits)
        if (is_num(direc_name)) {
            // Construct the path to the stat file
            char path[256];
            snprintf(path, sizeof(path), "/proc/%s/stat", direc_name);

            // Open the stat file
            FILE *stats = fopen(path, "r");
            if (stats != NULL) {
                char line[1024];

                // Read the line from the stat file
                if (fgets(line, sizeof(line), stats) != NULL) {
                    long pid, user, kernel;
                    char name[256];

                       int result = sscanf(line, "%ld (%255[^)]) %*s %*d %*d %*d %*d %*d %*d %*d %*d %ld %ld",
                                        &pid, name, &user, &kernel);

                    if (result == 4) {  // Ensure sscanf successfully parsed the data
                        long tot_time = user + kernel;

                        // Update max1 and max2 based on total time
                        if (tot_time > max1.total) {
                            max2 = max1;  // Copy max1 to max2 before updating max1
                            max1.pid = pid;
                            max1.kernel = kernel;
                            max1.user = user;
                            max1.total = tot_time;
                            strncpy(max1.name, name, sizeof(max1.name));  // Copy name
                        } else if (tot_time > max2.total) {
                            max2.pid = pid;
                            max2.kernel = kernel;
                            max2.user = user;
                            max2.total = tot_time;
                            strncpy(max2.name, name, sizeof(max2.name));  // Copy name
                        }
                    }
                }

                // Close the stat file
                fclose(stats);
            } else {
                perror("fopen");
            }
        }
    }

    // Format the result string with max1 and max2 information
    snprintf(result, 1024,
             "Process with max total time:\nPID: %ld, Name: %s, User Time: %ld, Kernel Time: %ld, Total Time: %ld\n\n"
             "Process with second max total time:\nPID: %ld, Name: %s, User Time: %ld, Kernel Time: %ld, Total Time: %ld\n",
             max1.pid, max1.name, max1.user, max1.kernel, max1.total,
             max2.pid, max2.name, max2.user, max2.kernel, max2.total);

    // Close the /proc directory
    closedir(proc_dir);

    return result;  // Return the formatted string
}

int main() {
    int server_fd, new_socket;
    struct sockaddr_in socket_address;
    int addrlen = sizeof(socket_address);
    char buffer[1024] = {0};

    // AF_INET for protocol family, SOCK_STREAM for TCP connection, 0 for IP protocol
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    socket_address.sin_family = AF_INET; // IPv4
    socket_address.sin_addr.s_addr = INADDR_ANY; // Bind to any IP address
    socket_address.sin_port = htons(8005); // Port number

    if (bind(server_fd, (struct sockaddr *)&socket_address, sizeof(socket_address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 30) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }
 // Echo back the message to the client
                  
    printf("Listening...\n");
    while(1)
    {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&socket_address, (socklen_t *)&addrlen)) < 0) {
            perror("Accept failed");
            exit(EXIT_FAILURE);
        }

        read(new_socket, buffer, 1024);
        printf("Message received: %s\n", buffer);

        char *info = get_top_two_processes();
        if (info != NULL) {
            send(new_socket, info, strlen(info), 0);
            printf("Process info sent\n");
            free(info);  // Don't forget to free the allocated memory
        } else {
            printf("Failed to retrieve process info\n");
        }
    }

    close(new_socket);
    close(server_fd);

    return 0;
}