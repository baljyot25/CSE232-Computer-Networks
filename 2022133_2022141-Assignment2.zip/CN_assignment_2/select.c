#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/select.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <ctype.h>

#define PORT 8005
#define MAX_CLIENTS 1024
#define BUFFER_SIZE 1024

// Define the process information structure
typedef struct {
    long pid;
    long user;
    long kernel;
    char name[256];
    long total;
} ProcessInfo;

// Helper function to check if a string is a number
int is_num(const char *str) {
    while (*str) {
        if (!isdigit(*str)) {
            return 0;
        }
        str++;
    }
    return 1;
}

// Function to retrieve the two processes with the maximum total times and return as a formatted string
char* get_top_two_processes() {
    DIR *proc_dir;
    struct dirent *entry;

    // Open the /proc directory
    proc_dir = opendir("/proc");
    if (proc_dir == NULL) {
        perror("opendir");
        return NULL;
    }

    // Initialize the max1 and max2 process info structs
    ProcessInfo max1 = {0, 0, 0, "", -1};  // Process with max total time
    ProcessInfo max2 = {0, 0, 0, "", -1};  // Process with second max total time

    // Buffer to hold the final result
    char *result = (char *)malloc(1024);  // Allocate memory for the result string
    if (result == NULL) {
        perror("malloc");
        closedir(proc_dir);
        return NULL;
    }
    result[0] = '\0';  // Initialize the result buffer with an empty string

    // Iterate over the entries in /proc
    while ((entry = readdir(proc_dir)) != NULL) {
        const char *direc_name = entry->d_name;

        // Check if the directory name is a PID (i.e., all digits)
        if (is_num(direc_name)) {
            // Construct the path to the stat file
            char path[256];
            snprintf(path, sizeof(path), "/proc/%s/stat", direc_name);

            // Open the stat file
            FILE *stats = fopen(path, "r");
            if (stats != NULL) {
                char line[1024];

                // Read the line from the stat file
                if (fgets(line, sizeof(line), stats) != NULL) {
                    long pid, user, kernel;
                    char name[256];

                       int result = sscanf(line, "%ld (%255[^)]) %*s %*d %*d %*d %*d %*d %*d %*d %*d %ld %ld",
                                        &pid, name, &user, &kernel);

                    if (result == 4) {  // Ensure sscanf successfully parsed the data
                        long tot_time = user + kernel;

                        // Update max1 and max2 based on total time
                        if (tot_time > max1.total) {
                            max2 = max1;  // Copy max1 to max2 before updating max1
                            max1.pid = pid;
                            max1.kernel = kernel;
                            max1.user = user;
                            max1.total = tot_time;
                            strncpy(max1.name, name, sizeof(max1.name));  // Copy name
                        } else if (tot_time > max2.total) {
                            max2.pid = pid;
                            max2.kernel = kernel;
                            max2.user = user;
                            max2.total = tot_time;
                            strncpy(max2.name, name, sizeof(max2.name));  // Copy name
                        }
                    }
                }

                // Close the stat file
                fclose(stats);
            } else {
                perror("fopen");
            }
        }
    }

    // Format the result string with max1 and max2 information
    snprintf(result, 1024,
             "Process with max total time:\nPID: %ld, Name: %s, User Time: %ld, Kernel Time: %ld, Total Time: %ld\n\n"
             "Process with second max total time:\nPID: %ld, Name: %s, User Time: %ld, Kernel Time: %ld, Total Time: %ld\n",
             max1.pid, max1.name, max1.user, max1.kernel, max1.total,
             max2.pid, max2.name, max2.user, max2.kernel, max2.total);

    // Close the /proc directory
    closedir(proc_dir);

    return result;  // Return the formatted string
}


int main() {
    int server_fd, new_socket, client_sockets[MAX_CLIENTS], max_sd, sd;
    struct sockaddr_in address;
    fd_set readfds;
    char buffer[BUFFER_SIZE];
    int opt = 1;
    int addrlen = sizeof(address);

    // Initialize client sockets
    for (int i = 0; i < MAX_CLIENTS; i++) {
        client_sockets[i] = 0;
    }

    // Create server socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Set socket options
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("Setsockopt failed");
        exit(EXIT_FAILURE);
    }

    // Bind the socket to the address and port
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Listening on port %d\n", PORT);

    while (1) {
        // Clear the socket set
        FD_ZERO(&readfds);

        // Add server socket to set
        FD_SET(server_fd, &readfds);
        max_sd = server_fd;

        // Add client sockets to set
        for (int i = 0; i < MAX_CLIENTS; i++) {
            sd = client_sockets[i];
            if (sd > 0) {
                FD_SET(sd, &readfds);
            }
            if (sd > max_sd) {
                max_sd = sd;
            }
        }

        // Wait for activity on any of the sockets
        int activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
        if ((activity < 0) && (errno != EINTR)) {
            perror("Select error");
        }

        // If something happened on the server socket, it's an incoming connection
        if (FD_ISSET(server_fd, &readfds)) {
            if ((new_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen)) < 0) {
                perror("Accept failed");
                exit(EXIT_FAILURE);
            }

            printf("New connection, socket fd is %d\n", new_socket);

            // Add new socket to the client_sockets array
            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client_sockets[i] == 0) {
                    client_sockets[i] = new_socket;
                    printf("Adding to list of sockets as %d\n", i);
                    break;
                }
            }
        }

        // Check all client sockets
        for (int i = 0; i < MAX_CLIENTS; i++) {
            sd = client_sockets[i];
            if (FD_ISSET(sd, &readfds)) {
                // Check if it was for closing, and also read the incoming message
                int valread = read(sd, buffer, BUFFER_SIZE);
                if (valread == 0) {
                    // Client disconnected
                    getpeername(sd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
                    printf("Host disconnected, IP %s, port %d\n",
                           inet_ntoa(address.sin_addr), ntohs(address.sin_port));

                    close(sd);
                    client_sockets[i] = 0;
                } else {
                    // Echo back the message to the client
                    char *info = get_top_two_processes();
                    printf("%s\n", info);
                    if (info != NULL) {
                        send(sd, info, strlen(info), 0);
                        // printf("Process info sent\n");
                        free(info);  // Don't forget to free the allocated memory
                        } else {
                            printf("Failed to retrieve process info\n");
                        }
                        printf("Process info sent\n");
                    }
            }
        }
    }

    return 0;
}
