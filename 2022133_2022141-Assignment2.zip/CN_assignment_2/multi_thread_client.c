#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sched.h>

#define MAX_CLIENTS 150

// Task for each client thread
void* client_task() {
    int sock = 0;

    struct sockaddr_in serv_addr;
    char hello[1024];
    snprintf(hello, sizeof(hello), "get_top_procs");
    char buffer[1024] = {0};

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation error");
        return NULL;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(8005);

    if (inet_pton(AF_INET, "192.168.1.19", &serv_addr.sin_addr) <= 0) {
        perror("Invalid address/Address not supported");
        return NULL;
    }

    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection Failed");
        return NULL;
    }

    send(sock, hello, strlen(hello), 0);
    printf("Thread: Hello message sent\n");
    read(sock, buffer, 1024);
    printf("Thread: Message received: %s\n", buffer);

    close(sock);
    return NULL;
}

int main(int argc, char* argv[]) {
    int number_of_clients = 1;

    if (argc > 1) {
        number_of_clients = atoi(argv[1]);
    }
    printf("Number of clients: %d\n", number_of_clients);

    if (number_of_clients > MAX_CLIENTS) {
        fprintf(stderr, "Max clients exceeded. Max allowed: %d\n", MAX_CLIENTS);
        return 1;
    }

    pthread_t threads[MAX_CLIENTS];
    int client_ids[MAX_CLIENTS];

    for (int i = 0; i < number_of_clients; i++) {
        client_ids[i] = i;
        if (pthread_create(&threads[i], NULL, client_task, NULL) != 0) {
            perror("Thread creation failed");
            return 1;
        }
    }

    for (int i = 0; i < number_of_clients; i++) {
        pthread_join(threads[i], NULL);
    }
    return 0;
}
